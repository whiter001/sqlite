# Creating Records
The code in this topic assumes a SQLite database has been mounted on the drive named "mydb".  For instructions on mounting such a drive, see [Creating Databases](Creating-Databases).  In addition, the code assumes that a table named "Users" has been created in the database.  For instructions on creating a table, see [Creating Tables](Creating-Tables).  The examples also assume that at least one record has been added to the Users table.  For instructions on adding records to the table, see [Creating Records](Creating-Records).

To update a table record inside of a SQLite database, you use the set-item PowerShell cmdlet, specifying the SQLite table record in the path argument and the record fields as arguments.  For instance:

{code:powershell}
PS> set-item -path mydb:/Users/1 -username "Beefarino" 
{code:powershell}

This example updates the username field value for the record with a primary key value of 1.

The SQLite provider allows you to express record fields in several ways.  You can use the dynamic parameters as shown above.  You can also specify the fields using a hashtable of field names and values; for example, this code is functionally equivalent to the previous example:

{code:powershell}
PS> set-item -path mydb:/Users/1 -value @{ username="Beefarino" }
{code:powershell}

The provider allows you to supply the field names and values from an object's properties.  The example below is functionally equivalent to the previous examples:

{code:powershell}
PS> $o = new-object psobject -property @{ username='Beefarino' }
PS> $o | set-item -path mydb:/Users/1
{code:powershell}

