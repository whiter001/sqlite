# Creating Records
The code in this topic assumes a SQLite database has been mounted on the drive named "mydb".  For instructions on mounting such a drive, see [Creating Databases](Creating-Databases).  In addition, the code assumes that a table named "Users" has been created in the database.  For instructions on creating a table, see [Creating Tables](Creating-Tables).

To create a table record inside of a SQLite database, you use the new-item PowerShell cmdlet, specifying the SQLite table in the path argument and the record fields as arguments.  For instance:

{code:powershell}
PS> new-item -path mydb:/Users -username "Jimbo" -userid 123
{code:powershell}

Note that any fields marked as NOT NULL in the containing table specification will be mandatory (except for the primary key field).

The SQLite provider allows you to express record fields in several ways.  You can use the dynamic parameters as shown above.  You can also specify the fields using a hashtable of field names and values; for example, this code is functionally equivalent to the previous example:

{code:powershell}
PS> new-item -path mydb:/Users -value @{ username="Jimbo"; userid=123 }
{code:powershell}

The provider allows you to supply the field names and values from an object's properties.  The example below is functionally equivalent to the previous examples:

{code:powershell}
PS> $o = new-object psobject -property @{ username='Jimbo'; userid=123 }
PS> $o | new-item -path mydb:/Users
{code:powershell}

