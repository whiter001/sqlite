# Removing Records
To remove a record, use the remove-item cmdlet, specifying the path to the database table record you wish to remove:
{code:powershell}
PS> remove-item mydb:/Users/1
{code:powershell}