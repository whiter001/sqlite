# Loading Existing Databases

To mount an existing SQLite database file, simply specify the file location of the database file in the call to new-psdrive or mount-sqlite.

See [Creating Databases](Creating-Databases).