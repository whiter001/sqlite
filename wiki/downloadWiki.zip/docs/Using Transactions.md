# Using Transactions

The SQLite PowerShell provider is transaction-aware.  If the PowerShell session has an active transaction, the SQLite provider enlists the transaction for any database activity **if you specify the -useTransaction parameter of the provider cmdlets**.

For example, this code wraps the creation of 100 users in a transaction.  If the transaction fails (e.g., if the computer crashes), none of the 100 user records will be added to the database:

{code:powershell}
PS> start-transaction
PS> 1..100 | new-item mydb:/Users -username { "UserID$_" } -usetransaction
PS> complete-transaction
{code:powershell}

Transactions can span multiple operations on the same database:

{code:powershell}
PS> start-transaction
PS> $users = get-childitems mydb:/Users -filter "status=1" -usetransaction
PS> $users | set-item -value @{ status=0, active=0 } -usetransaction
PS> remove-item -mydb:/Users -filter 'active=0' -usetransaction
PS> complete-transaction
{code:powershell}