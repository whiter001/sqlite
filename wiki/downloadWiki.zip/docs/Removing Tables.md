# Removing Tables
To remove tables from a SQLite database, use the remove-item cmdlet, specifying the path to the table you want to remove:
{code:powershell}
PS> remove-item -path mydb:/Users 
{code:powershell}