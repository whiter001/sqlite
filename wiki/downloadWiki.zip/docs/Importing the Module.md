# Importing the Module

Before you can use the SQLite PowerShell Provider, you must import the SQLite module into your PowerShell session using the import-module cmdlet:

{code:powershell}
PS> import-module SQLite
{code:powershell}

This loads and registers the necessary assemblies and adds the SQLite provider to your session.