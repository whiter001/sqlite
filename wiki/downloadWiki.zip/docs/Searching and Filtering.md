# Searching and Filtering

The SQLite provider supports native (SQLite-based) filtering through the use of the -filter parameter in various item cmdlets.  For example, this command searches a table for records with a username field value of 'Beefarino':

{code:powershell}
PS> get-childitem mydb:/Users -filter "username='Beefarino'"
{code:powershell}

The syntax of the filter parameter is open to the syntax supported by the [SQLite WHERE clause](http://www.sqlite.org/lang_select.html#whereclause).  You can create very powerful search using very little PowerShell.  This example finds all users with the letter 'f' in their username:

{code:powershell}
PS> get-childitem mydb:/Users -filter "username like '%f%'"
{code:powershell}

The -filter parameter is supported on these SQLite provider cmdlets:
* get-childItem
* get-item
* set-item
* remove-item

This example updates the Status field for all records where the username starts with 'Beef':

{code:powershell}
PS> set-item mydb:/Users -filter "username like 'beef%'" -value @{ status=0 }
{code:powershell}


This example removes all database table records with a Status field equal to 0:

{code:powershell}
PS> remove-item mydb:/Users -filter "status = 0"
{code:powershell}
