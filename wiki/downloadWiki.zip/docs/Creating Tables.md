# Creating Tables

The code in this topic assumes a SQLite database has been mounted on the drive named "mydb".  For instructions on mounting such a drive, see [Creating Databases](Creating-Databases).

To create a table inside of a SQLite database, you use the new-item PowerShell cmdlet, specifying the mounted SQLite drive in the path argument and the table specification for the table as the value argument.  For instance:

{code:powershell}
PS> new-item -path mydb:/Users -value "id INTEGER PRIMARY KEY, username TEXT NOT NULL, userid INTEGER"
{code:powershell}
where:
| path | specifies the path to the SQLite database drive, and optionally the new table (Users in this example) |
| value | is a valid table specification, suitable for inclusion in a CREATE TABLE DDL statement |

The SQLite provider allows you to express the table specification in several ways.  You can use a DDL string, as shown above.  You can also specify the table using a hashtable of column definitions; for example, this code is functionally equivalent to the previous example:

{code:powershell}
PS> new-item -path mydb:/Users -value @{ id="INTEGER PRIMARY KEY"; username="TEXT NOT NULL"; userid="INTEGER" }
{code:powershell}

In addition, the provider offers a simplified syntax that allows you to express the table specification as a sequence of parameters to new-item.  The example below is functionally equivalent to the previous two examples:

{code:powershell}
PS> new-item -path mydb:/Users -id INTEGER PRIMARY KEY -username TEXT NOT NULL -userid INTEGER;
{code:powershell}