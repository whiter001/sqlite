# Creating Databases

These instructions assume you have already imported the SQLite module into your PowerShell session.  If not, please refer to [Importing the Module](Importing-the-Module).

To create a new SQLite database using the provider, you need to mount a new SQLite drive in your session using the new-psdrive PowerShell cmdlet.  For example:

{code:powershell}
PS> new-psdrive -psprovider SQLite -name mydb -root "DataSource=datafile.sqlite"
{code:powershell}
where:
| psprovider | MUST be the string 'SQLite' |
| name | is the name of the new PowerShell drive to which the SQLite database will be associated |
| root | is a valid SQLite connection string ([examples](http://www.connectionstrings.com/sqlite)) |

The SQLite module includes the mount-sqlite helper cmdlet that simplifies the syntax for mounting SQLite databases as drives:

{code:powershell}
PS> mount-sqlite -name mydb -dataSource datafile.sqlite
{code:powershell}
where:
| name | is the name of the new PowerShell drive to which the SQLite database will be associated |
| dataSource | is the name of the SQLite data file; if unspecified, a transient in-memory database is created |
